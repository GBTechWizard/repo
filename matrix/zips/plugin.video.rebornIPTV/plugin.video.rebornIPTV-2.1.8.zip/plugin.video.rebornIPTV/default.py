# -*- coding: UTF-8 -*-
# Copyright 2017 Team Soa by ‘Xmapiss’
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
if 64 - 64: i11iIiiIii
import urllib , urllib2 , re , xbmcplugin , xbmcgui , sys , xbmc , xbmcaddon , xbmcvfs , plugintools , datetime , base64
import json , os , time
from net import Net
from cookielib import CookieJar
OO0o = int ( sys . argv [ 1 ] )
reload ( sys )
sys . setdefaultencoding ( 'utf8' )
if 81 - 81: Iii1I1 + OO0O0O % iiiii % ii1I - ooO0OO000o
ii11i = 'R3born IPTV'
oOooOoO0Oo0O = 'plugin.video.rebornIPTV'
iI1 = xbmcaddon . Addon ( id = oOooOoO0Oo0O )
i1I11i = xbmc . translatePath ( iI1 . getAddonInfo ( 'profile' ) ) . decode ( 'utf-8' )
OoOoOO00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOooOoO0Oo0O , 'icon.png' ) )
I11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOooOoO0Oo0O , 'fanart.jpg' ) )
O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOooOoO0Oo0O , 'addon.xml' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOooOoO0Oo0O , 'resources' ) )
iI1 = xbmcaddon . Addon ( id = oOooOoO0Oo0O )
I1ii11iIi11i = plugintools . get_runtime_path ( )
I1IiI = iI1 . getAddonInfo ( 'path' )
o0OOO = plugintools . get_setting ( "host1" )
iIiiiI = plugintools . get_setting ( "portnumber1" )
Iii1ii1II11i = plugintools . get_setting ( "username1" )
iI111iI = plugintools . get_setting ( "password1" )
IiII = plugintools . get_setting ( "host2" )
iI1Ii11111iIi = plugintools . get_setting ( "portnumber2" )
i1i1II = plugintools . get_setting ( "username2" )
O0oo0OO0 = plugintools . get_setting ( "password2" )
I1i1iiI1 = plugintools . get_setting ( "host3" )
iiIIIII1i1iI = plugintools . get_setting ( "portnumber3" )
o0oO0 = plugintools . get_setting ( "username3" )
oo00 = plugintools . get_setting ( "password3" )
o00 = plugintools . get_setting ( "parental" )
Oo0oO0ooo = '/resources/icons/'
o0oOoO00o = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' )
i1 = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'noposter.jpg' )
oOOoo00O0O = 'http://r3bornpt.pe.hu/testes/tvi.php'
i1111 = 'http://r3bornpt.pe.hu/testes/tvi_cats.php'
i11 = 'http://tviplayer.iol.pt/'
I11 = 'http://r3bornpt.pe.hu/testes/sic.php'
Oo0o0000o0o0 = 'http://r3bornpt.pe.hu/testes/sic_rad.php'
oOo0oooo00o = '.ts'
oO0o0o0ooO0oO = xbmcgui . Dialog ( )
oo0o0O00 = '1'
oO = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:41.0) Gecko/20100101 Firefox/41.0"
i1iiIIiiI111 = os . path . join ( i1I11i , 'cookieTvi.db' )
oooOOOOO = os . path . join ( i1I11i , 'cookieSIC.db' )
i1iiIII111ii = "http://p.jwpcdn.com/6/12/jwplayer.flash.swf"
i1iIIi1 = 'XXX' , 'Adult' , 'Adults' , 'ADULT' , 'ADULTS' , 'adult' , 'adults' , '❤ADULTS❤', 'Porn' , 'PORN' , 'porn' , 'Porn' , 'xxx' , 'Xxx' , 'FOR ADULTS'
ii11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOooOoO0Oo0O , 'compare.txt' ) )
if 6 - 6: I1I11I1I1I * OooO0OO
def iiiIi ( ) :
 IiIIIiI1I1 = plugintools . get_setting ( 'servico' )
 global host
 global port
 global username
 global password
 global urlss
 global urlssM
 global urlssSER
 global url_vod_cats
 global url_vod_series
 global url_vod_episodes
 global url_vod_c
 global url_live_c
 global url_live_cats
 global api_url
 global url_epg
 if IiIIIiI1I1 == '0' :
  host = o0OOO
  port = iIiiiI
  username = Iii1ii1II11i
  password = iI111iI
 elif IiIIIiI1I1 == '1' :
  host = IiII
  port = iI1Ii11111iIi
  username = i1i1II
  password = O0oo0OO0
 elif IiIIIiI1I1 == '2' :
  host = I1i1iiI1
  port = iiIIIII1i1iI
  username = o0oO0
  password = oo00
  if 86 - 86: i11I1IIiiIi + oOo + iiIiIiIi - o0oooO0OO0O / Oooo
 urlss = ( '%s:%s/live/%s/%s/' ) % ( host , port , username , password )
 urlssM = ( '%s:%s//movie/%s/%s/' ) % ( host , port , username , password )
 urlssSER = ( '%s:%s//series/%s/%s/' ) % ( host , port , username , password )
 url_vod_c = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_vod_streams&category_id=' ) % ( host , port , username , password )
 url_vod_series = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_series' ) % ( host , port , username , password )
 url_vod_episodes = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_series_info&series_id=' ) % ( host , port , username , password )
 url_vod_cats = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_vod_categories' ) % ( host , port , username , password )
 url_live_c = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_live_streams&category_id=' ) % ( host , port , username , password )
 url_live_cats = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_live_categories' ) % ( host , port , username , password )
 api_url = ( '%s:%s/player_api.php?username=%s&password=%s' ) % ( host , port , username , password )
 url_epg = ( '%s:%s/player_api.php?username=%s&password=%s&action=get_short_epg&stream_id=' ) % ( host , port , username , password )
 if 67 - 67: OO0oOoo / oo0Oo00Oo0 % iII11i % O0O00o0OOO0
 if 27 - 27: IIII % o0O0 . ii1I11II1ii1i % oOo - i11I1IIiiIi - oo0Oo00Oo0
def Iiiii ( ) :
 if not plugintools . get_setting ( "password1" ) :
  plugintools . open_settings_dialog ( )
 if plugintools . get_setting ( "improve" ) == "true" :
  OoO0 = xbmc . translatePath ( "special://userdata/advancedsettings.xml" )
  if not os . path . exists ( OoO0 ) :
   Ooooo = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' )
   I1I1i = os . path . join ( os . path . join ( Ooooo , 'resources' ) , 'advancedsettings.xml' )
   file = open ( I1I1i )
   oOOOoo0O0OoO = file . read ( )
   file . close ( )
   file = open ( OoO0 , "w" )
   file . write ( oOOOoo0O0OoO )
   file . close ( )
   plugintools . message ( ii11i , '[COLOR snow][B]New advanced streaming settings added![/COLOR][/B]' )
 ii1i1I1i ( '[B][COLOR orange]Account Info[/COLOR][/B]' , 'nothing' , 8 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'info.png' ) )
 ii1i1I1i ( '[B][COLOR dodgerblue]Live TV[/COLOR][/B]' , 'nothing' , 4 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Live TV.png' ) )
 ii1i1I1i ( '[B][COLOR dodgerblue]Video On Demmand[/COLOR][/B]' , 'nothing' , 5 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'vod.png' ) )
 if 53 - 53: IIII + I1I11I1I1I * Oooo
 ii1i1I1i ( '[B][COLOR red]Settings[/COLOR][/B]' , 'nothing' , 9 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'settings.png' ) )
 if 61 - 61: ii1I * OO0oOoo / iiiii . i11iIiiIii . oOo
 if 60 - 60: oo0Oo00Oo0 / oo0Oo00Oo0
 if 46 - 46: iII11i * OO0oOoo - i11I1IIiiIi * Oooo - o0O0
def oo0 ( ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( api_url )
 O000oo0O = json . load ( o00OooOooo )
 OOOO = O000oo0O [ "user_info" ] [ "auth" ]
 if OOOO == 1 :
  i11i1 = O000oo0O [ "user_info" ] [ "username" ]
  IIIii1II1II = O000oo0O [ "user_info" ] [ "password" ]
  i1I1iI = O000oo0O [ "user_info" ] [ "active_cons" ]
  oo0OooOOo0 = O000oo0O [ "user_info" ] [ "max_connections" ]
  o0O = O000oo0O [ "user_info" ] [ "status" ]
  O00oO = O000oo0O [ "user_info" ] [ "exp_date" ]
  I11i1I1I = O000oo0O [ "user_info" ] [ "created_at" ]
  oO0Oo = datetime . datetime . fromtimestamp ( int ( O00oO ) ) . strftime ( '%H:%M - %d/%m/%Y' )
  oOOoo0Oo = datetime . datetime . fromtimestamp ( int ( I11i1I1I ) ) . strftime ( '%H:%M - %d/%m/%Y' )
  if 78 - 78: oo0Oo00Oo0
  OO00Oo ( '[B][COLOR dodgerblue]Created At: [/COLOR][/B]' + oOOoo0Oo , 'nothing' , 20 , I1IiI + 'icon.png' )
  OO00Oo ( '[B][COLOR dodgerblue]Expiration Date: [/COLOR][/B]' + oO0Oo , 'nothing' , 20 , I1IiI + 'icon.png' )
  OO00Oo ( '[B][COLOR dodgerblue]Username: [/COLOR][/B]' + i11i1 , 'nothing' , 20 , I1IiI + 'icon.png' )
  
  OO00Oo ( '[B][COLOR dodgerblue]Active Connections: [/COLOR][/B]' + i1I1iI , 'nothing' , 20 , I1IiI + 'icon.png' )
  OO00Oo ( '[B][COLOR dodgerblue]Max Connections: [/COLOR][/B]' + oo0OooOOo0 , 'nothing' , 20 , I1IiI + 'icon.png' )
  OO00Oo ( '[B][COLOR dodgerblue]Status: [/COLOR][/B]' + o0O , 'nothing' , 20 , I1IiI + 'icon.png' )
 else :
  plugintools . message ( '[COLOR red][B]LOGIN FAILED![/COLOR][/B]' , '[COLOR snow][B]Possible reasons: Wrong Host, Port, Username or Password.' , 'Please reconfigure R3born Addon with correct details![/COLOR][/B]' )
  plugintools . open_settings_dialog ( )
  if 51 - 51: IIII * iiIiIiIi + oo0Oo00Oo0 + i11I1IIiiIi
  if 66 - 66: oOo
def oO000Oo000 ( ) :
 plugintools . open_settings_dialog ( )
 if 4 - 4: Oooo
def OOoO0O00o0 ( ) :
 o00OooOooo = urllib2 . urlopen ( i1111 )
 iII = json . load ( o00OooOooo )
 for o0 in range ( len ( iII ) ) :
  ooOooo000oOO = iII [ o0 ]
  if 59 - 59: ooO0OO000o + iiiii * oOo + ii1I
  i11i1 = ooOooo000oOO [ "Titulo" ]
  oo0o0O00 = ooOooo000oOO [ "Link" ]
  Oo0OoO00oOO0o = ooOooo000oOO [ "Imagem" ]
  OOO00O = oo0o0O00
  ii1i1I1i ( i11i1 , OOO00O , 3 , Oo0OoO00oOO0o )
  if 84 - 84: Oooo * i11I1IIiiIi / oo0Oo00Oo0 - Iii1I1
def IiI1 ( url ) :
 Oo0O00Oo0o0 = 'http://r3bornpt.pe.hu/testes/tvi.php?categ=' + url
 o00OooOooo = urllib2 . urlopen ( Oo0O00Oo0o0 )
 O00O0oOO00O00 = json . load ( o00OooOooo )
 for o0 in range ( len ( O00O0oOO00O00 ) ) :
  i1Oo00 = O00O0oOO00O00 [ o0 ]
  if 31 - 31: o0O0 . oOo / Iii1I1
  i11i1 = i1Oo00 [ "Titulo" ]
  oo0o0O00 = i1Oo00 [ "Link" ]
  Oo0OoO00oOO0o = i1Oo00 [ "Imagem" ]
  o000O0o = i1Oo00 [ "Descricao" ]
  url = oo0o0O00
  ii1i1I1i ( i11i1 , url , 10 , Oo0OoO00oOO0o )
  if 42 - 42: oOo
def II ( url ) :
 Ii1I1IIii1II = 'http://r3bornpt.pe.hu/testes/tvi_n.php?pagina=' + url
 o00OooOooo = urllib2 . urlopen ( Ii1I1IIii1II )
 O0 = json . load ( o00OooOooo )
 for o0 in range ( len ( O0 ) ) :
  ii1ii1ii = O0 [ o0 ]
  oo0o0O00 = ii1ii1ii [ "Link" ]
  i11i1 = ii1ii1ii [ "Data" ] + ' |' + ii1ii1ii [ "EP" ] + ' |' + ii1ii1ii [ "Titulo" ]
  Oo0OoO00oOO0o = ii1ii1ii [ "Imagem" ]
  url = oo0o0O00
  OO00Oo ( i11i1 , url , 11 , Oo0OoO00oOO0o )
  if 91 - 91: IIII
def iiIii ( ) :
 o00OooOooo = urllib2 . urlopen ( I11 )
 iII = json . load ( o00OooOooo )
 for o0 in range ( len ( iII ) ) :
  ooOooo000oOO = iII [ o0 ]
  if 79 - 79: iiiii / Iii1I1
  i11i1 = ooOooo000oOO [ "Titulo" ] . encode ( 'utf8' )
  oo0o0O00 = ooOooo000oOO [ "Link" ] . encode ( 'utf8' )
  Oo0OoO00oOO0o = ooOooo000oOO [ "Imagem" ]
  OOO00O = oo0o0O00
  ii1i1I1i ( i11i1 , OOO00O , 16 , Oo0OoO00oOO0o )
  if 75 - 75: oOo % iiIiIiIi % iiIiIiIi . o0O0
def III1iII1I1ii ( ) :
 o00OooOooo = urllib2 . urlopen ( Oo0o0000o0o0 )
 iII = json . load ( o00OooOooo )
 for o0 in range ( len ( iII ) ) :
  ooOooo000oOO = iII [ o0 ]
  if 61 - 61: ooO0OO000o
  i11i1 = ooOooo000oOO [ "Titulo" ] . encode ( 'utf8' )
  oo0o0O00 = ooOooo000oOO [ "Link" ] . encode ( 'utf8' )
  Oo0OoO00oOO0o = ooOooo000oOO [ "Imagem" ]
  OOO00O = oo0o0O00
  ii1i1I1i ( i11i1 , OOO00O , 16 , Oo0OoO00oOO0o )
  if 64 - 64: ii1I11II1ii1i / oOo - Iii1I1 - oo0Oo00Oo0
def O0oOoOOOoOO ( url ) :
 url = url . replace ( " " , "%20" )
 Ii1I1IIii1II = 'http://r3bornpt.pe.hu/testes/sic_n.php?pagina=' + url
 ii1ii11IIIiiI = CookieJar ( )
 O00OOOoOoo0O = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( ii1ii11IIIiiI ) )
 O00OOOoOoo0O . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0' ) ]
 o00OooOooo = O00OOOoOoo0O . open ( Ii1I1IIii1II )
 O0 = json . load ( o00OooOooo )
 for o0 in range ( len ( O0 ) ) :
  ii1ii1ii = O0 [ o0 ]
  oo0o0O00 = ii1ii1ii [ "Link" ]
  i11i1 = ii1ii1ii [ "Titulo" ]
  Oo0OoO00oOO0o = ii1ii1ii [ "Imagem" ]
  url = oo0o0O00
  OO00Oo ( i11i1 , url , 18 , Oo0OoO00oOO0o )
  if 77 - 77: O0O00o0OOO0 % O0O00o0OOO0 * Oooo - i11iIiiIii
def Oo0oO ( url ) :
 url = url . replace ( " " , "%20" )
 Ii1I1IIii1II = 'http://r3bornpt.pe.hu/testes/sic_l.php?pagina=' + url
 ii1ii11IIIiiI = CookieJar ( )
 O00OOOoOoo0O = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( ii1ii11IIIiiI ) )
 O00OOOoOoo0O . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0' ) ]
 o00OooOooo = O00OOOoOoo0O . open ( Ii1I1IIii1II )
 O0 = json . load ( o00OooOooo )
 for o0 in range ( len ( O0 ) ) :
  ii1ii1ii = O0 [ o0 ]
  oo0o0O00 = ii1ii1ii [ "Link" ]
  i11i1 = ii1ii1ii [ "Titulo" ]
  url = oo0o0O00
  if not 'http:' in url : url = 'http:' + url
 IIiIi1iI ( url , i11i1 )
 if 35 - 35: iII11i % Iii1I1 - Iii1I1
 if 16 - 16: ooO0OO000o % oOo - ooO0OO000o + iII11i
def i1I1i ( ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( '' )
 Ii = json . load ( o00OooOooo )
 for o0 in range ( len ( Ii ) ) :
  iii1i = Ii [ o0 ]
  i11i1 = iii1i [ "name" ]
  id = iii1i [ "stream_id" ]
  Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
  OOO00O = urlss + str ( id ) + oOo0oooo00o
  OO00Oo ( i11i1 , OOO00O , 1 , Oo0OoO00oOO0o )
  if 39 - 39: O0O00o0OOO0 - Iii1I1 % i11iIiiIii * o0O0 . IIII
def OOooo0O00o ( ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url_vod_cats )
 oOOoOooOo = json . load ( o00OooOooo )
 ii1i1I1i ( 'PROGRAMAS TVI' , 'nothing' , 12 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'TVI_logo_2017.png' ) )
 ii1i1I1i ( 'PROGRAMAS SIC' , 'nothing' , 15 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Sic_logo.png' ) )
 ii1i1I1i ( 'PROGRAMAS SIC RADICAL' , 'nothing' , 17 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Logosicradical.png' ) )
 ii1i1I1i ( 'SERIES' , 'nothing' , 100 , os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , OoOoOO00 ) )
 for o0 in range ( len ( oOOoOooOo ) ) :
  O000oo = oOOoOooOo [ o0 ]
  i11i1 = O000oo [ "category_name" ]
  id = O000oo [ "category_id" ]
  Oo0OoO00oOO0o = OoOoOO00
  OOO00O = url_vod_c + str ( id )
  ii1i1I1i ( i11i1 , OOO00O , 6 , Oo0OoO00oOO0o )
  if 20 - 20: OO0oOoo % iII11i / iII11i + iII11i
  if 45 - 45: Oooo - IIII - iiiii - i11I1IIiiIi . ooO0OO000o / Iii1I1
def oo0o00O ( ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url_vod_series )
 oOOoOooOo = json . load ( o00OooOooo )
 if 51 - 51: iII11i - i11I1IIiiIi * O0O00o0OOO0
 for o0 in range ( len ( oOOoOooOo ) ) :
  O000oo = oOOoOooOo [ o0 ]
  i11i1 = O000oo [ "name" ]
  id = O000oo [ "series_id" ]
  Oo0OoO00oOO0o = O000oo [ "cover" ]
  OOO00O = url_vod_episodes + str ( id )
  ii1i1I1i ( i11i1 , OOO00O , 101 , Oo0OoO00oOO0o )
  if 66 - 66: iiiii + Iii1I1
def I1IiiI ( url , name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url )
 IIi = json . load ( o00OooOooo )
 if o00 == "true" and name in i1iIIi1 :
  i1Iii1i1I = plugintools . keyboard_input ( default_text = "" , title = "Parental lock" )
  if i1Iii1i1I == plugintools . get_setting ( "parentalpin" ) :
   for OOoO00 in range ( len ( IIi [ "episodes" ] ) ) :
    if 40 - 40: I1I11I1I1I * iII11i + OO0oOoo % O0O00o0OOO0
    if 74 - 74: Oooo - OooO0OO + iiiii + o0O0 / oOo
    if 23 - 23: Iii1I1
    if 85 - 85: iII11i
    if 84 - 84: I1I11I1I1I . OO0O0O % iiiii + iII11i % iiiii % i11I1IIiiIi
    if 42 - 42: i11I1IIiiIi / oo0Oo00Oo0 / iiIiIiIi + O0O00o0OOO0 / oOo
    if 84 - 84: ii1I11II1ii1i * ooO0OO000o + OooO0OO
    if 53 - 53: O0O00o0OOO0 % ooO0OO000o . IIII - OO0O0O - IIII * ooO0OO000o
    if 77 - 77: OO0O0O * i11I1IIiiIi
    if 95 - 95: I1I11I1I1I + i11iIiiIii
    I1Ii = OOoO00 + 1
    name = "Season : " + str ( I1Ii )
    Oo0OoO00oOO0o = IIi [ "seasons" ] [ OOoO00 ] [ "cover_big" ]
    Oo0OoO00oOO0o = str ( Oo0OoO00oOO0o )
    xbmc . log ( "TESTEEEEEEEEEEEEEEEEEEEEEEEE : " + Oo0OoO00oOO0o , level = xbmc . LOGNOTICE )
    OO00Oo ( name , url , 102 , Oo0OoO00oOO0o )
  else :
   if 94 - 94: iII11i - ooO0OO000o . OO0oOoo % oo0Oo00Oo0 . i11iIiiIii + Iii1I1
   exit ( )
 else :
  if 26 - 26: oo0Oo00Oo0 - OO0O0O - I1I11I1I1I / i11I1IIiiIi . oOo % OO0O0O
  for OOoO00 in range ( len ( IIi [ "episodes" ] ) ) :
   if 91 - 91: iiIiIiIi . OO0O0O / Oooo + ii1I
   if 42 - 42: ii1I11II1ii1i . iiIiIiIi . ii1I11II1ii1i - o0oooO0OO0O
   if 40 - 40: ii1I11II1ii1i - i11iIiiIii / iII11i
   if 35 - 35: iII11i - I1I11I1I1I % iiIiIiIi . iiiii % iII11i
   if 47 - 47: O0O00o0OOO0 - iII11i . ooO0OO000o + iiiii . i11iIiiIii
   if 94 - 94: iiIiIiIi * iII11i / OooO0OO / iII11i
   if 87 - 87: OooO0OO . IIII
   if 75 - 75: ii1I11II1ii1i + oOo + iiIiIiIi * oo0Oo00Oo0 % Oooo . O0O00o0OOO0
   if 55 - 55: OO0oOoo . I1I11I1I1I
   if 61 - 61: OooO0OO % IIII . OooO0OO
   I1Ii = OOoO00 + 1
   name = "Season : " + str ( I1Ii )
   Oo0OoO00oOO0o = IIi [ "seasons" ] [ OOoO00 ] [ "cover_big" ]
   Oo0OoO00oOO0o = str ( Oo0OoO00oOO0o )
   if 100 - 100: o0O0 * Iii1I1
   ii1i1I1i ( name , url , 102 , Oo0OoO00oOO0o )
   if 64 - 64: OO0oOoo % OO0O0O * Oooo
def o0iI11I1II ( url , name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url )
 IIi = json . load ( o00OooOooo )
 if o00 == "true" and name in i1iIIi1 :
  i1Iii1i1I = plugintools . keyboard_input ( default_text = "" , title = "Parental lock" )
  if i1Iii1i1I == plugintools . get_setting ( "parentalpin" ) :
   for OOoO00 in range ( len ( IIi [ "episodes" ] ) ) :
    if 40 - 40: OO0O0O / oOo % o0oooO0OO0O + ooO0OO000o
    if 27 - 27: ooO0OO000o * oOo * OO0O0O
    if 86 - 86: i11I1IIiiIi * OO0oOoo . O0O00o0OOO0
    if 32 - 32: iiIiIiIi . IIII * oo0Oo00Oo0
    if 93 - 93: iiIiIiIi % ii1I . iII11i . i11iIiiIii
    if 56 - 56: o0oooO0OO0O % Iii1I1 - I1I11I1I1I
    if 100 - 100: iII11i - Iii1I1 % Oooo * OO0oOoo + I1I11I1I1I
    if 88 - 88: iiiii - i11I1IIiiIi * Iii1I1 * iiiii . iiiii
    if 33 - 33: o0O0 + O0O00o0OOO0 * Oooo / OO0O0O - I1I11I1I1I
    if 54 - 54: o0O0 / OO0oOoo . Oooo % O0O00o0OOO0
    url = "NONE"
    I1Ii = OOoO00 + 1
    name = "Season : " + str ( I1Ii )
    Oo0OoO00oOO0o = IIi [ "seasons" ] [ OOoO00 ] [ "cover_big" ]
    Oo0OoO00oOO0o = str ( Oo0OoO00oOO0o )
    OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
  else :
   if 57 - 57: i11iIiiIii . o0oooO0OO0O - iII11i - Oooo + oOo
   exit ( )
 else :
  oO00oooOOoOo0 = re . findall ( '\d+' , name )
  OoOOoOooooOOo = str ( oO00oooOOoOo0 )
  OoOOoOooooOOo = str ( OoOOoOooooOOo ) [ 1 : - 1 ]
  OoOOoOooooOOo = str ( OoOOoOooooOOo ) [ 1 : - 1 ]
  if 87 - 87: I1I11I1I1I
  for o0 in range ( len ( IIi [ "episodes" ] [ OoOOoOooooOOo ] ) ) :
   name = IIi [ "episodes" ] [ OoOOoOooooOOo ] [ o0 ] [ "title" ]
   id = IIi [ "episodes" ] [ OoOOoOooooOOo ] [ o0 ] [ "id" ]
   oOOOoo0O0oO = IIi [ "episodes" ] [ OoOOoOooooOOo ] [ o0 ] [ "container_extension" ]
   if 6 - 6: OO0oOoo * iiIiIiIi + O0O00o0OOO0
   Oo0OoO00oOO0o = i1
   url = urlssSER + str ( id ) + '.' + str ( oOOOoo0O0oO )
   xbmc . log ( "TESTESSSSSSSSSSSS : " + Oo0OoO00oOO0o , level = xbmc . LOGNOTICE )
   OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
   if 44 - 44: iII11i % i11I1IIiiIi + iiiii - Iii1I1 - iII11i - ooO0OO000o
def O0Oo0oOOoooOOOOo ( url , name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url )
 o0oO0O0o0O00O = json . load ( o00OooOooo )
 if o00 == "true" and name in i1iIIi1 :
  i1Iii1i1I = plugintools . keyboard_input ( default_text = "" , title = "Parental lock" )
  if i1Iii1i1I == plugintools . get_setting ( "parentalpin" ) :
   for o0 in range ( len ( o0oO0O0o0O00O ) ) :
    OoO000O0Oo = o0oO0O0o0O00O [ o0 ]
    name = OoO000O0Oo [ "name" ]
    id = OoO000O0Oo [ "stream_id" ]
    oOOOoo0O0oO = OoO000O0Oo [ "container_extension" ]
    Oo0OoO00oOO0o = OoO000O0Oo [ "stream_icon" ]
    url = urlssM + str ( id ) + '.' + str ( oOOOoo0O0oO )
    OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
  else :
   if 63 - 63: OO0O0O * i11iIiiIii % OO0O0O * i11iIiiIii
   exit ( )
 else :
  for o0 in range ( len ( o0oO0O0o0O00O ) ) :
   OoO000O0Oo = o0oO0O0o0O00O [ o0 ]
   name = OoO000O0Oo [ "name" ]
   id = OoO000O0Oo [ "stream_id" ]
   oOOOoo0O0oO = OoO000O0Oo [ "container_extension" ]
   Oo0OoO00oOO0o = OoO000O0Oo [ "stream_icon" ]
   url = urlssM + str ( id ) + '.' + str ( oOOOoo0O0oO )
   OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
   if 32 - 32: OO0oOoo
def I11iiiiIIii1I ( name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url_live_cats )
 II1IiiIi1i = json . load ( o00OooOooo )
 for o0 in range ( len ( II1IiiIi1i ) ) :
  iiI11ii1I1 = II1IiiIi1i [ o0 ]
  name = iiI11ii1I1 [ "category_name" ]
  id = iiI11ii1I1 [ "category_id" ]
  if name == "PORTUGAL" :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Portugal.png' )
  elif name in [ 'BRASIL' , 'Brasil' , 'brasil' , 'BRAZIL' , 'Brazil' , 'brazil' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Brazil.png' )
  elif name in [ 'ESPANHA' , 'Espanha' , 'espanha' , 'SPAIN' , 'Spain' , 'spain' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Spain.png' )
  elif name in [ 'FRANÇA' , 'França' , 'frança' , 'FRANCA' , 'Franca' , 'franca' , 'FRANCE' , 'France' , 'france' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'France.png' )
  elif name in [ 'SUIÇA' , 'Suiça' , 'suiça' , 'SUICA' , 'Suica' , 'suica' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Switzerland.png' )
  elif name in [ 'ALEMANHA' , 'Alemanha' , 'alemanha' , 'GERMANY' , 'Germany' , 'germany' , 'DEUTSCHLAND' , 'Deutschland' , 'deutschland' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Germany.png' )
  elif name in [ 'ITÁLIA' , 'Itália' , 'itália' , 'ITALIA' , 'Italia' , 'italia' , 'ITALY' , 'Italy' , 'italy' , 'ITALIANI' , 'Italiani' , 'italiani' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Italy.png' )
  elif name in [ 'HOLANDA' , 'Holanda' , 'holanda' , 'HOLAND' , 'Holand' , 'holand' , 'DENMARK' , 'denmark' , 'Denmark' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Denmark.png' )
  elif name in [ 'BÉLGICA' , 'Bélgica' , 'bélgica' , 'BELGIUM' , 'Belgium' , 'belgium' , 'BELGICA' , 'Belgica' , 'belgica' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Belgium.png' )
  elif name in [ 'USA' , 'usa' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'USA.png' )
  elif name in [ 'UK' , 'uk' , 'INGLATERRA' , 'Inglaterra' , 'inglaterra' , 'ENGLAND' , 'England' , 'england' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'UK.png' )
  elif name in [ 'CANAIS LOW' , 'LOW' , 'Low' , 'low' , 'Canais Low' , 'canais low' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'low.png' )
  elif name in [ 'RÁDIOS' , 'Rádios' , 'rádios' , 'RADIOS' , 'Radios' , 'radios' , 'RADIO' , 'Radio' , 'radio' , 'RÁDIO' , 'Rádio' , 'rádio' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'radios.png' )
  elif name in [ 'XXX' , 'Adult' , 'Adults' , 'ADULT' , 'ADULTS' , 'adult' , 'adults' , 'Porn' , 'PORN' , 'porn' , 'Porn' , 'xxx' , 'Xxx' , 'FOR ADULTS' , 'ADULTOS' , 'Adultos' , 'adultos' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , '18+.png' )
  else :
   Oo0OoO00oOO0o = OoOoOO00
  OOO00O = url_live_c + str ( id )
  ii1i1I1i ( name , OOO00O , 7 , Oo0OoO00oOO0o )
  if 82 - 82: ooO0OO000o % oo0Oo00Oo0 / i11I1IIiiIi + oOo / iiIiIiIi / o0O0
def oOo0OOoO0 ( name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url_live_cats )
 II1IiiIi1i = json . load ( o00OooOooo )
 for o0 in range ( len ( II1IiiIi1i ) ) :
  iiI11ii1I1 = II1IiiIi1i [ o0 ]
  name = iiI11ii1I1 [ "category_name" ]
  id = iiI11ii1I1 [ "category_id" ]
  if name == "PORTUGAL" :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Portugal.png' )
  elif name in [ 'BRASIL' , 'Brasil' , 'brasil' , 'BRAZIL' , 'Brazil' , 'brazil' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Brazil.png' )
  elif name in [ 'ESPANHA' , 'Espanha' , 'espanha' , 'SPAIN' , 'Spain' , 'spain' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Spain.png' )
  elif name in [ 'FRANÇA' , 'França' , 'frança' , 'FRANCA' , 'Franca' , 'franca' , 'FRANCE' , 'France' , 'france' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'France.png' )
  elif name in [ 'SUIÇA' , 'Suiça' , 'suiça' , 'SUICA' , 'Suica' , 'suica' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Switzerland.png' )
  elif name in [ 'ALEMANHA' , 'Alemanha' , 'alemanha' , 'GERMANY' , 'Germany' , 'germany' , 'DEUTSCHLAND' , 'Deutschland' , 'deutschland' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Germany.png' )
  elif name in [ 'ITÁLIA' , 'Itália' , 'itália' , 'ITALIA' , 'Italia' , 'italia' , 'ITALY' , 'Italy' , 'italy' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Italy.png' )
  elif name in [ 'HOLANDA' , 'Holanda' , 'holanda' , 'HOLAND' , 'Holand' , 'holand' , 'DENMARK' , 'denmark' , 'Denmark' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Denmark.png' )
  elif name in [ 'BÉLGICA' , 'Bélgica' , 'bélgica' , 'BELGIUM' , 'Belgium' , 'belgium' , 'BELGICA' , 'Belgica' , 'belgica' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'Belgium.png' )
  elif name in [ 'USA' , 'usa' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'USA.png' )
  elif name in [ 'UK' , 'uk' , 'INGLATERRA' , 'Inglaterra' , 'inglaterra' , 'ENGLAND' , 'England' , 'england' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'UK.png' )
  elif name in [ 'CANAIS LOW' , 'LOW' , 'Low' , 'low' , 'Canais Low' , 'canais low' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'low.png' )
  elif name in [ 'RÁDIOS' , 'Rádios' , 'rádios' , 'RADIOS' , 'Radios' , 'radios' , 'RADIO' , 'Radio' , 'radio' , 'RÁDIO' , 'Rádio' , 'rádio' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , 'radios.png' )
  elif name in [ 'XXX' , 'Adult' , 'Adults' , 'ADULT' , 'ADULTS' , 'adult' , 'adults' , 'Porn' , 'PORN' , 'porn' , 'Porn' , 'xxx' , 'Xxx' , 'FOR ADULTS' , 'ADULTOS' , 'Adultos' , 'adultos' ] :
   Oo0OoO00oOO0o = os . path . join ( os . path . join ( o0oOoO00o , 'resources/art' ) , '18+.png' )
  else :
   Oo0OoO00oOO0o = OoOoOO00
  OOO00O = url_live_c + str ( id )
  ii1i1I1i ( name , OOO00O , 13 , Oo0OoO00oOO0o )
  if 11 - 11: o0oooO0OO0O . i11I1IIiiIi * IIII * iiiii + ii1I11II1ii1i
def IiII111i1i11 ( url , name ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url )
 Ii = json . load ( o00OooOooo )
 if o00 == "true" and name in i1iIIi1 :
  i1Iii1i1I = plugintools . keyboard_input ( default_text = "" , title = "Parental lock" )
  if i1Iii1i1I == plugintools . get_setting ( "parentalpin" ) :
   for o0 in range ( len ( Ii ) ) :
    iii1i = Ii [ o0 ]
    name = iii1i [ "name" ]
    id = iii1i [ "stream_id" ]
    Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
    url = urlss + str ( id ) + oOo0oooo00o
    OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
  else :
   exit ( )
 else :
  for o0 in range ( len ( Ii ) ) :
   iii1i = Ii [ o0 ]
   name = iii1i [ "name" ]
   id = iii1i [ "stream_id" ]
   Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
   url = urlss + str ( id ) + oOo0oooo00o
   OO00Oo ( name , url , 1 , Oo0OoO00oOO0o )
   if 40 - 40: ii1I11II1ii1i * IIII * i11iIiiIii
def oo0OO00OoooOo ( url , name , id ) :
 iiiIi ( )
 o00OooOooo = urllib2 . urlopen ( url )
 Ii = json . load ( o00OooOooo )
 if o00 == "true" and name in i1iIIi1 :
  i1Iii1i1I = plugintools . keyboard_input ( default_text = "" , title = "Parental lock" )
  if i1Iii1i1I == plugintools . get_setting ( "parentalpin" ) :
   II1i111Ii1i = open ( ii11iIi1I , "w" )
   for o0 in range ( len ( Ii ) ) :
    iii1i = Ii [ o0 ]
    name = iii1i [ "name" ]
    id = iii1i [ "stream_id" ]
    iii1 = iii1i [ "epg_channel_id" ]
    if iii1 <> None :
     ooO0oooOO0 = url_epg + str ( id ) + '&limit=2'
     o0o = urllib2 . urlopen ( ooO0oooOO0 )
     oo0oOOOoo00 = json . load ( o0o )
     try :
      iiIiIIIiiI = oo0oOOOoo00 [ "epg_listings" ] [ 0 ] [ "title" ]
      iiI1IIIi = oo0oOOOoo00 [ "epg_listings" ] [ 1 ] [ "title" ]
      II11IiIi11 = oo0oOOOoo00 [ "epg_listings" ] [ 0 ] [ "start_timestamp" ]
      IIOOO0O00O0OOOO = oo0oOOOoo00 [ "epg_listings" ] [ 1 ] [ "start_timestamp" ]
      I1iiii1I = datetime . datetime . fromtimestamp ( int ( II11IiIi11 ) ) . strftime ( '%H:%M' )
      OOo0 = datetime . datetime . fromtimestamp ( int ( IIOOO0O00O0OOOO ) ) . strftime ( '%H:%M' )
     except IndexError :
      iiIiIIIiiI = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
      iiI1IIIi = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
      I1iiii1I = ' '
      OOo0 = ' '
     oO00ooooO0o = base64 . b64decode ( iiIiIIIiiI )
     oo0o = base64 . b64decode ( iiI1IIIi )
     Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
     url = urlss + str ( id ) + oOo0oooo00o
     name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]' + ' [COLOR green]|> NOW: ' + I1iiii1I + ' < - >[/COLOR]' + oO00ooooO0o + ' \n[COLOR red]NEXT: ' + OOo0 + ' < - > [/COLOR]' + oo0o + '[COLOR red] <|[/COLOR]'
     if 51 - 51: oo0Oo00Oo0 % I1I11I1I1I
    else :
     Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
     url = urlss + str ( id ) + oOo0oooo00o
     name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'
     if 60 - 60: I1I11I1I1I / OO0oOoo . I1I11I1I1I / o0O0 . IIII
    II1i111Ii1i . write ( name + '\n' )
    if 92 - 92: oOo + o0O0 * iII11i % I1I11I1I1I
    if 42 - 42: OooO0OO
  else :
   exit ( )
 else :
  II1i111Ii1i = open ( ii11iIi1I , "w" )
  for o0 in range ( len ( Ii ) ) :
   iii1i = Ii [ o0 ]
   name = iii1i [ "name" ]
   id = iii1i [ "stream_id" ]
   iii1 = iii1i [ "epg_channel_id" ]
   if iii1 <> None :
    ooO0oooOO0 = url_epg + str ( id ) + '&limit=2'
    o0o = urllib2 . urlopen ( ooO0oooOO0 )
    oo0oOOOoo00 = json . load ( o0o )
    try :
     iiIiIIIiiI = oo0oOOOoo00 [ "epg_listings" ] [ 0 ] [ "title" ]
     iiI1IIIi = oo0oOOOoo00 [ "epg_listings" ] [ 1 ] [ "title" ]
     II11IiIi11 = oo0oOOOoo00 [ "epg_listings" ] [ 0 ] [ "start_timestamp" ]
     IIOOO0O00O0OOOO = oo0oOOOoo00 [ "epg_listings" ] [ 1 ] [ "start_timestamp" ]
     I1iiii1I = datetime . datetime . fromtimestamp ( int ( II11IiIi11 ) ) . strftime ( '%H:%M' )
     OOo0 = datetime . datetime . fromtimestamp ( int ( IIOOO0O00O0OOOO ) ) . strftime ( '%H:%M' )
    except IndexError :
     iiIiIIIiiI = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
     iiI1IIIi = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
     I1iiii1I = ' '
     OOo0 = ' '
    oO00ooooO0o = base64 . b64decode ( iiIiIIIiiI )
    oo0o = base64 . b64decode ( iiI1IIIi )
    Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
    url = urlss + str ( id ) + oOo0oooo00o
    name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]' + ' [COLOR green]|> NOW: ' + I1iiii1I + ' < - >[/COLOR]' + oO00ooooO0o + ' \n[COLOR red]NEXT: ' + OOo0 + ' < - > [/COLOR]' + oo0o + '[COLOR red] <|[/COLOR]'
    if 76 - 76: I1I11I1I1I * O0O00o0OOO0 % o0O0
    if 57 - 57: OO0O0O - ii1I / o0O0 - Iii1I1 * iiiii % ooO0OO000o
   else :
    Oo0OoO00oOO0o = iii1i [ "stream_icon" ]
    url = urlss + str ( id ) + oOo0oooo00o
    name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'
    if 68 - 68: iiiii * oo0Oo00Oo0 % oOo - IIII
   II1i111Ii1i . write ( name + '\n' )
 II1i111Ii1i . close ( )
 I1 = open ( ii11iIi1I )
 i1Iii1i1I = I1 . read ( )
 oOoOo0O0OOOoO ( i1Iii1i1I )
 if 50 - 50: ii1I11II1ii1i
def IIiIi1iI ( url , name ) :
 url = url + '|User-Agent=%s' % urllib2 . quote ( 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36' , safe = '' )
 IIIIiii1IIii = xbmc . PlayList ( 1 )
 IIIIiii1IIii . clear ( )
 II1i11I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = "DefaultVideo.png" )
 II1i11I . setInfo ( 'video' , { 'Title' : name } )
 ii1I1IIii11 = xbmcgui . DialogProgress ( )
 ii1I1IIii11 . create ( 'R3born' , 'A carregar...' + name )
 IIIIiii1IIii . add ( url , II1i11I )
 ii1I1IIii11 . close ( )
 del ii1I1IIii11
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11I )
 O0o0oO = xbmc . Player ( )
 O0o0oO . play ( url , II1i11I )
 if 38 - 38: Oooo % oOo + o0oooO0OO0O . i11iIiiIii
def oo0000ooooO0o ( url , name ) :
 if 40 - 40: o0oooO0OO0O + ii1I * OO0oOoo
 try :
  O0oOOoooOO0O = ooo00Ooo ( url )
  if 93 - 93: i11iIiiIii - I1I11I1I1I * o0oooO0OO0O * oo0Oo00Oo0 % Iii1I1 + iiiii
 except :
  xbmc . log ( 'Unexpected error: {0:s} :{1:s}' . format ( sys . exc_info ( ) [ 0 ] , sys . exc_info ( ) [ 1 ] ) )
  O0oOOoooOO0O = ''
 if O0oOOoooOO0O :
  I1i1i1 = re . compile ( "[:=] '(.*)playlist\.m3u8\?([^']*)'\s*[,;]" ) . findall ( O0oOOoooOO0O )
  if I1i1i1 and I1i1i1 [ 0 ] :
   oo0o0O00 = I1i1i1 [ 0 ] [ 0 ] + OoO0O00O0oo0O ( I1i1i1 [ 0 ] [ 0 ] + 'playlist.m3u8?' + I1i1i1 [ 0 ] [ 1 ] )
   ooo00Ooo ( oo0o0O00 )
   IIIIiii1IIii = xbmc . PlayList ( 1 )
   IIIIiii1IIii . clear ( )
   I1IiI11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = "DefaultVideo.png" )
   I1IiI11 . setInfo ( 'Video' , { } )
   ii1I1IIii11 = xbmcgui . DialogProgress ( )
   ii1I1IIii11 . create ( 'R3born' , 'A carregar...' + name )
   ii1I1IIii11 . close ( )
   del ii1I1IIii11
   I1IiI11 . setProperty ( 'mimetype' , 'video' )
   IIIIiii1IIii . add ( oo0o0O00 , I1IiI11 )
   iI1iiiiIii = xbmc . Player ( )
   iI1iiiiIii . play ( IIIIiii1IIii )
 else :
  sys . exit ( 0 )
  if 19 - 19: i11I1IIiiIi - OooO0OO . Iii1I1
def OoO0O00O0oo0O ( url ) :
 try :
  O0oOOoooOO0O = ooo00Ooo ( url )
 except :
  xbmc . log ( 'Unexpected error: {0:s} :{1:s}' . format ( sys . exc_info ( ) [ 0 ] , sys . exc_info ( ) [ 1 ] ) )
  O0oOOoooOO0O = ''
 if O0oOOoooOO0O :
  try :
   ooOo00 = plugintools . get_setting ( 'tipostr' )
   OOoo = 'b(15|10)00000'
   if ooOo00 == '0' :
    OOoo = 'b(15|10)00000'
   elif ooOo00 == '1' :
    OOoo = 'b(75|50)0000'
   elif ooOo00 == '2' :
    OOoo = 'b(25|20)0000'
   elif ooOo00 == '3' :
    OOoo = 'b(64|48)000_ao'
   xbmc . log ( "tipostr=" + ooOo00 + " tipostr_b=" + OOoo )
   I1i1i1 = re . compile ( '(chunklist.*_' + OOoo + '\.m3u8\?[^\\n]*)' ) . findall ( O0oOOoooOO0O )
   if I1i1i1 and I1i1i1 [ 0 ] :
    return I1i1i1 [ 0 ] [ 0 ]
   else :
    I1i1i1 = re . compile ( '(chunklist.*\.m3u8\?[^\\n]*)' ) . findall ( O0oOOoooOO0O )
    if I1i1i1 and I1i1i1 [ 0 ] :
     return I1i1i1 [ 0 ]
  except :
   xbmc . log ( 'Unexpected error: {0:s} :{1:s}' . format ( sys . exc_info ( ) [ 0 ] , sys . exc_info ( ) [ 1 ] ) )
   return ''
 else :
  sys . exit ( 0 )
  if 50 - 50: i11I1IIiiIi
def ooo00Ooo ( url , referer = i11 ) :
 if not os . path . exists ( i1I11i ) : xbmcvfs . mkdir ( i1I11i )
 if 43 - 43: ooO0OO000o . Oooo / o0oooO0OO0O
 i1iI1 = Net ( cookie_file = i1iiIIiiI111 , proxy = '' , user_agent = oO , http_debug = True )
 if os . path . exists ( i1iiIIiiI111 ) : i1iI1 . set_cookies ( i1iiIIiiI111 )
 try :
  i11ii1ii11i = { 'Referer' : referer }
  ooO0OoOO = i1iI1 . http_GET ( url , headers = i11ii1ii11i ) . content . encode ( 'latin-1' , 'ignore' )
  i1iI1 . save_cookies ( i1iiIIiiI111 )
  return ooO0OoOO
 except :
  xbmc . log ( "abrir_url fail =" + url )
  return ''
  if 55 - 55: ii1I11II1ii1i - oo0Oo00Oo0 + ooO0OO000o + O0O00o0OOO0 % iII11i
  if 41 - 41: ii1I - oo0Oo00Oo0 - iII11i
def oOoOo0O0OOOoO ( text ) :
 id = 10147
 III11I1 = '[COLOR snow][B]Programação[/COLOR][/B]'
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 IIi1IIIi = xbmcgui . Window ( id )
 O00Ooo = 50
 while ( O00Ooo > 0 ) :
  try :
   xbmc . sleep ( 5 )
   O00Ooo -= 1
   IIi1IIIi . getControl ( 1 ) . setLabel ( III11I1 )
   IIi1IIIi . getControl ( 5 ) . setText ( text )
   if 52 - 52: o0oooO0OO0O - OooO0OO + o0oooO0OO0O % iiIiIiIi
   return
  except :
   pass
   if 35 - 35: OO0O0O
   if 42 - 42: o0O0 . I1I11I1I1I . ii1I + oOo + OO0oOoo + I1I11I1I1I
   if 31 - 31: O0O00o0OOO0 . OO0oOoo - ii1I11II1ii1i . iiiii / iiiii
   if 56 - 56: i11I1IIiiIi / Oooo / i11iIiiIii + iiiii - OooO0OO - oo0Oo00Oo0
def Iii1iiIi1II ( ) :
 OO0O00oOo = [ ]
 ii1II = sys . argv [ 2 ]
 if len ( ii1II ) >= 2 :
  iI1I = sys . argv [ 2 ]
  OooOoOo = iI1I . replace ( '?' , '' )
  if ( iI1I [ len ( iI1I ) - 1 ] == '/' ) :
   iI1I = iI1I [ 0 : len ( iI1I ) - 2 ]
  III1I1Iii1iiI = OooOoOo . split ( '&' )
  OO0O00oOo = { }
  for o0 in range ( len ( III1I1Iii1iiI ) ) :
   i1Iii11I1i = { }
   i1Iii11I1i = III1I1Iii1iiI [ o0 ] . split ( '=' )
   if ( len ( i1Iii11I1i ) ) == 2 : OO0O00oOo [ i1Iii11I1i [ 0 ] ] = i1Iii11I1i [ 1 ]
 return OO0O00oOo
 if 72 - 72: OO0O0O * iII11i % ii1I11II1ii1i / i11I1IIiiIi
def I11i1II ( name , url , iconimage , number_of_items ) :
 Ooo = True
 I1IiI11 = xbmcgui . ListItem ( name , iconImage = "DefaultImage.png" , thumbnailImage = iconimage )
 I1IiI11 . setProperty ( 'fanart_image' , I1IiI + Oo0oO0ooo + 'fanart.jpg' )
 I1IiI11 . setInfo ( type = 'image' , infoLabels = { "Title" : name } )
 Ooo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = I1IiI11 , totalItems = number_of_items )
 return Ooo
 if 21 - 21: OooO0OO
def OO00Oo ( name , url , mode , iconimage ) :
 name = name . encode ( 'utf8' , 'replace' )
 I1ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Ooo = True
 I1IiI11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I1IiI11 . setProperty ( 'fanart_image' , I1IiI + Oo0oO0ooo + 'fanart.jpg' )
 I1IiI11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Ooo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1ii1 , listitem = I1IiI11 , isFolder = False )
 return Ooo
 if 99 - 99: ii1I11II1ii1i . o0O0 % IIII * IIII . ii1I
def ii1i1I1i ( name , url , mode , iconimage ) :
 name = name . encode ( 'utf8' , 'replace' )
 I1ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Ooo = True
 I1IiI11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I1IiI11 . setProperty ( 'fanart_image' , I1IiI + Oo0oO0ooo + 'fanart.jpg' )
 I1IiI11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Ooo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1ii1 , listitem = I1IiI11 , isFolder = True )
 return Ooo
 if 72 - 72: OO0oOoo % o0oooO0OO0O + i11I1IIiiIi / Oooo + IIII
iI1I = Iii1iiIi1II ( )
OOO00O = None
i11i1 = None
I1I1iI1IIIiIiIi = None
if 27 - 27: o0oooO0OO0O + oOo - OO0oOoo + Iii1I1 . iII11i
try : OOO00O = urllib . unquote_plus ( iI1I [ "url" ] )
except : pass
try : i11i1 = urllib . unquote_plus ( iI1I [ "name" ] )
except : pass
try : I1I1iI1IIIiIiIi = int ( iI1I [ "mode" ] )
except : pass
if 46 - 46: IIII
if 45 - 45: ii1I11II1ii1i
if I1I1iI1IIIiIiIi == None or OOO00O == None or len ( OOO00O ) < 1 : Iiiii ( )
elif I1I1iI1IIIiIiIi == 1 : IIiIi1iI ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 2 : i1I1i ( )
elif I1I1iI1IIIiIiIi == 3 : IiI1 ( OOO00O )
elif I1I1iI1IIIiIiIi == 4 : I11iiiiIIii1I ( i11i1 )
elif I1I1iI1IIIiIiIi == 5 : OOooo0O00o ( )
elif I1I1iI1IIIiIiIi == 100 : oo0o00O ( )
elif I1I1iI1IIIiIiIi == 101 : I1IiiI ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 102 : o0iI11I1II ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 6 : O0Oo0oOOoooOOOOo ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 7 : IiII111i1i11 ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 8 : oo0 ( )
elif I1I1iI1IIIiIiIi == 9 : oO000Oo000 ( )
elif I1I1iI1IIIiIiIi == 10 : II ( OOO00O )
elif I1I1iI1IIIiIiIi == 11 : oo0000ooooO0o ( OOO00O , i11i1 )
elif I1I1iI1IIIiIiIi == 12 : OOoO0O00o0 ( )
elif I1I1iI1IIIiIiIi == 13 : oo0OO00OoooOo ( OOO00O , i11i1 , id )
elif I1I1iI1IIIiIiIi == 14 : oOo0OOoO0 ( i11i1 )
elif I1I1iI1IIIiIiIi == 15 : iiIii ( )
elif I1I1iI1IIIiIiIi == 16 : O0oOoOOOoOO ( OOO00O )
elif I1I1iI1IIIiIiIi == 17 : III1iII1I1ii ( )
elif I1I1iI1IIIiIiIi == 18 : Oo0oO ( OOO00O )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
