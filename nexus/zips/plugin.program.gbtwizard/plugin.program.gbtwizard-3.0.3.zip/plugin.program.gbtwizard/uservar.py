import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/GBTechWizard/repo/master/nexus/wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/GBTechWizard/repo/master/nexus/wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
