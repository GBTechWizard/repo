# -*- coding: UTF-8 -*-
# Copyright 2017 Team Soa by ‘Xmapiss’
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import urllib.request, urllib.parse, urllib.error,urllib.request,urllib.error,urllib.parse,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,xbmcvfs,plugintools,datetime,base64
import json,os,time
from net import Net
from http.cookiejar import CookieJar
import importlib
pluginhandle = int(sys.argv[1])
importlib.reload(sys)


addname = 'GRiptv IPTV'
addon_id = 'plugin.video.GRiptv'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
xbmc.log("TESTE="+icon,level=xbmc.LOGINFO)
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
abcdrf = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'addon.xml'))
fiolder = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources'))
selfAddon = xbmcaddon.Addon(id=addon_id)
addonDir = plugintools.get_runtime_path()
addonfolder = selfAddon.getAddonInfo('path')
host1 = plugintools.get_setting("host1")
port1 = plugintools.get_setting("portnumber1")
username1 = plugintools.get_setting("username1")
password1 = plugintools.get_setting("password1")
parental = plugintools.get_setting("parental")
artfolder = '/resources/icons/'
bandeiras = xbmcaddon.Addon().getAddonInfo('path')
tvi = 'http://r3bornpt.pe.hu/testes/tvi.php'
tvi_cats = 'http://r3bornpt.pe.hu/testes/tvi_cats.php'
base_url = 'http://tviplayer.iol.pt/'
sic = 'http://r3bornpt.pe.hu/testes/sic.php'
sicr = 'http://r3bornpt.pe.hu/testes/sic_rad.php'
# ts = '.mpegts'
ts = '.m3u8'
dialog = xbmcgui.Dialog()
link = '1'
user_agent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:41.0) Gecko/20100101 Firefox/41.0"
cookie_TviFile = os.path.join(datapath,'cookieTvi.db')
cookie_SICFile = os.path.join(datapath,'cookieSIC.db')
default_flash_Referer = "http://p.jwpcdn.com/6/12/jwplayer.flash.swf"
a = 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx','Xxx', 'FOR ADULTS'
comparefile = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'compare.txt'))
path = xbmcaddon.Addon().getAddonInfo('path')
def servicos():
	servico = plugintools.get_setting('servico')
	global host
	global port
	global username
	global password
	global urlss
	global urlssM
	global urlssS
	global url_vod_cats
	global url_ser_cats
	global url_vod_c
	global url_ser_c
	global url_series
	global url_live_c
	global url_live_cats
	global api_url
	global url_epg
	global url_series_info
	if servico == '0':
		host = host1
		port = port1
		username = username1
		password = password1
	
	urlss = ('%s:%s/live/%s/%s/')%(host,port,username,password)
	urlssM = ('%s:%s//movie/%s/%s/')%(host,port,username,password)
	urlssS = ('%s:%s//series/%s/%s/')%(host,port,username,password)
	url_vod_c = ('%s:%s/player_api.php?username=%s&password=%s&action=get_vod_streams&category_id=')%(host,port,username,password)
	url_ser_c = ('%s:%s/player_api.php?username=%s&password=%s&action=get_series_streams&category_id=')%(host,port,username,password)
	url_vod_cats = ('%s:%s/player_api.php?username=%s&password=%s&action=get_vod_categories')%(host,port,username,password)
	url_ser_cats = ('%s:%s/player_api.php?username=%s&password=%s&action=get_series_categories')%(host,port,username,password)
	url_series = ('%s:%s/player_api.php?username=%s&password=%s&action=get_series')%(host,port,username,password)
	url_series_info = ('%s:%s/player_api.php?username=%s&password=%s&action=get_series_info&series_id=')%(host,port,username,password)
	url_live_c = ('%s:%s/player_api.php?username=%s&password=%s&action=get_live_streams&category_id=')%(host,port,username,password)
	url_live_cats = ('%s:%s/player_api.php?username=%s&password=%s&action=get_live_categories')%(host,port,username,password)
	api_url =('%s:%s/player_api.php?username=%s&password=%s')%(host,port,username,password)
	url_epg = ('%s:%s/player_api.php?username=%s&password=%s&action=get_short_epg&stream_id=')%(host,port,username,password)


def CATEGORIES():
	if not plugintools.get_setting("password1"):
		plugintools.open_settings_dialog()
	if plugintools.get_setting("improve")=="true":
		melhor = xbmc.translatePath("special://userdata/advancedsettings.xml")
		if not os.path.exists(melhor):
			path = xbmcaddon.Addon().getAddonInfo('path')
			files = os.path.join(os.path.join(path,'resources'), 'advancedsettings.xml')
			file = open(files)
			data = file.read()
			file.close()
			file = open(melhor,"w")
			file.write(data)
			file.close()
			plugintools.message(addname, '[COLOR snow][B]New advanced streaming settings added![/COLOR][/B]')
	addDir('[B][COLOR orange]Account Info[/COLOR][/B]', 'nothing', 8, os.path.join(os.path.join(bandeiras,'resources/art'), 'info.png'))
	addDir('[B][COLOR dodgerblue]Live TV[/COLOR][/B]', 'nothing', 4, os.path.join(os.path.join(bandeiras,'resources/art'), 'Live TV.png'))
	addDir('[B][COLOR dodgerblue]Movies[/COLOR][/B]', 'nothing', 5, os.path.join(os.path.join(bandeiras,'resources/art'), 'vod.png'))
	addDir('[B][COLOR dodgerblue]Series[/COLOR][/B]', 'nothing', 19, os.path.join(os.path.join(bandeiras,'resources/art'), 'vod.png'))
	addDir('[B][COLOR red]Settings[/COLOR][/B]', 'nothing', 9, os.path.join(os.path.join(bandeiras,'resources/art'), 'settings.png'))
	

	
def U_Info():
	servicos()
	reqs = urllib.request.Request(api_url, headers={'User-Agent' : "Magic Browser"}) 
	jsonSrc     = urllib.request.urlopen( reqs )
	jsonObjectInfo       = json.load(jsonSrc)
	auth = jsonObjectInfo["user_info"]["auth"]
	if auth == 1:
		name = jsonObjectInfo["user_info"]["username"]
		passw = jsonObjectInfo["user_info"]["password"]
		active_con = jsonObjectInfo["user_info"]["active_cons"]
		max_con = jsonObjectInfo["user_info"]["max_connections"]
		status = jsonObjectInfo["user_info"]["status"]
		exp_date = jsonObjectInfo["user_info"]["exp_date"]
		cre_date = jsonObjectInfo["user_info"]["created_at"]
		exp = datetime.datetime.fromtimestamp(int(exp_date)).strftime('%H:%M - %d/%m/%Y')
		created = datetime.datetime.fromtimestamp(int(cre_date)).strftime('%H:%M - %d/%m/%Y')
	
		addItem('[B][COLOR dodgerblue]Created At: [/COLOR][/B]'+ created, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Expiration Date: [/COLOR][/B]'+ exp, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Username: [/COLOR][/B]'+ name, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Password: [/COLOR][/B]'+ passw, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Active Connections: [/COLOR][/B]'+ active_con, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Max Connections: [/COLOR][/B]'+ max_con, 'nothing', 20, addonfolder + 'icon.png')
		addItem('[B][COLOR dodgerblue]Status: [/COLOR][/B]'+ status, 'nothing', 20, addonfolder + 'icon.png')
	else:
		plugintools.message('[COLOR red][B]LOGIN FAILED![/COLOR][/B]', '[COLOR snow][B]Possible reasons: Wrong Host, Port, Username or Password.', 'Please reconfigure GRiptv Addon with correct details![/COLOR][/B]')
		plugintools.open_settings_dialog()


def SETT():
		plugintools.open_settings_dialog()
		
def TVI0():
	reqs = urllib.request.Request(tvi_cats, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	cat       = json.load(jsonSrc)
	for i in range(len(cat)):
		cats = cat[i]

		name = cats["Titulo"]
		link = cats["Link"]
		iconimage = cats["Imagem"]
		url = link
		addDir(name,url,3,iconimage)
		
def TVI(url):
	a1234 = 'http://r3bornpt.pe.hu/testes/tvi.php?categ=' + url
	jsonSrc     = urllib.request.urlopen(a1234)
	novela       = json.load(jsonSrc)
	for i in range(len(novela)):
		novelas = novela[i]

		name = novelas["Titulo"]
		link = novelas["Link"]
		iconimage = novelas["Imagem"]
		descricao = novelas["Descricao"]
		url = link
		addDir(name,url,10,iconimage)
		
def TVI_S(url):
	a123 = 'http://r3bornpt.pe.hu/testes/tvi_n.php?pagina=' + url
	jsonSrc     = urllib.request.urlopen(a123)
	ep       = json.load(jsonSrc)
	for i in range(len(ep)):
		eps = ep[i]
		link = eps["Link"]
		name = eps["Data"] + ' |' + eps["EP"] + ' |' + eps["Titulo"]
		iconimage = eps["Imagem"]
		url = link
		addItem(name,url,11,iconimage)
		
def SIC0():
	jsonSrc     = urllib.request.urlopen(sic)
	cat       = json.load(jsonSrc)
	for i in range(len(cat)):
		cats = cat[i]

		name = cats["Titulo"].encode('utf8')
		link = cats["Link"].encode('utf8')
		iconimage = cats["Imagem"]
		url = link
		addDir(name,url,16,iconimage)
		
def SICR():
	jsonSrc     = urllib.request.urlopen(sicr)
	cat       = json.load(jsonSrc)
	for i in range(len(cat)):
		cats = cat[i]

		name = cats["Titulo"].encode('utf8')
		link = cats["Link"].encode('utf8')
		iconimage = cats["Imagem"]
		url = link
		addDir(name,url,16,iconimage)
		
def SIC_S(url):
	url = url.replace(" ", "%20")
	a123 = 'http://r3bornpt.pe.hu/testes/sic_n.php?pagina=' + url
	cj = CookieJar()
	opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
	opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0')]
	jsonSrc = opener.open(a123)
	ep       = json.load(jsonSrc)
	for i in range(len(ep)):
		eps = ep[i]
		link = eps["Link"]
		name = eps["Titulo"]
		iconimage = eps["Imagem"]
		url = link
		addItem(name,url,18,iconimage)
		
def SIC_L(url):
	url = url.replace(" ", "%20")
	a123 = 'http://r3bornpt.pe.hu/testes/sic_l.php?pagina=' + url
	cj = CookieJar()
	opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
	opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0')]
	jsonSrc = opener.open(a123)
	ep       = json.load(jsonSrc)
	for i in range(len(ep)):
		eps = ep[i]
		link = eps["Link"]
		name = eps["Titulo"]
		url = link
		if not'http:'in url:url='http:'+url
	test(url,name)	
		

def AllLIVE():
	servicos()
	reqs = urllib.request.Request('', headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen('')
	canal       = json.load(jsonSrc)	
	for i in range(len(canal)):
		canais = canal[i]
		name = canais["name"]
		id = canais["stream_id"]
		iconimage = canais["stream_icon"]
		url = urlss + str(id) + ts
		addItem(name,url,1,iconimage)
		
def LIST_VOD_CAT():
	servicos()
	reqs = urllib.request.Request(url_vod_cats, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	cat_vod       = json.load(jsonSrc)	
	for i in range(len(cat_vod)):
		cats_vod = cat_vod[i]
		name = cats_vod["category_name"]
		id = cats_vod["category_id"]
		iconimage = icon
		url = url_vod_c + str(id)
		addDir(name,url,6,iconimage)
		
def LIST_SER_CAT():
	servicos()
	reqs = urllib.request.Request(url_ser_cats, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	cat_ser       = json.load(jsonSrc)	
	for i in range(len(cat_ser)):
		cats_ser = cat_ser[i]
		name = cats_ser["category_name"]
		id = cats_ser["category_id"]
		iconimage = icon
		url=id
		xbmc.log("TESTE="+url,level=xbmc.LOGINFO)
		addDir(name,url,20,iconimage)
		
		
def LIST_SERIES(name,url):
	servicos()
	reqs = urllib.request.Request(url_series, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	serie       = json.load(jsonSrc)
	cat_id=url
	if parental == "true" and name in a:
		text = plugintools.keyboard_input(default_text="", title="Parental lock")
		if text==plugintools.get_setting("parentalpin"):
			for i in range(len(serie)):
				series = serie[i]
				name = series["name"]
				ids = series["category_id"]
				id_s= series["series_id"]
				iconimage = series["cover"]
				#url = urlssM + str(id) + '.' + str(extensao)
				url = url_series_info + str(id_s)		
				if ids==cat_id:
					addDir(name,url,21,iconimage)
					
		else:
			
			exit()
	else:
		for i in range(len(serie)):
			series = serie[i]
			name = series["name"]
			ids = series["category_id"]
			id_s= series["series_id"]
			iconimage = series["cover"]
			#url = urlssM + str(id) + '.' + str(extensao)
			url = url_series_info + str(id_s)
			if ids==cat_id:
				addDir(name,url,21,iconimage)
				
				
def LIST_SEASONS(name,url):
	servicos()
	reqs = urllib.request.Request(url, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	season       = json.load(jsonSrc)
	namer = season['episodes']
	names = len(season['episodes'])
	#cover = season['seasons'][1]['cover']
	#teste= season['episodes']['1'][0]['title']
	#xbmc.log("TESTE="+str(teste),level=xbmc.LOGNOTICE)
	for i in range(names):
		numero= i+1
		seasons = "Season "+str(numero)
		cover = season['info']['cover']
		iconimage = cover
		#testes = seasons.replace("Season ","")
		#xbmc.log("TESTE="+testes,level=xbmc.LOGNOTICE)
		addDir(seasons,url,22,iconimage)
		
def LIST_EPISODES(name,url):
	servicos()
	numero= name.replace("Season ","")
	reqs = urllib.request.Request(url, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	episodio       = json.load(jsonSrc)
	#namer = season['episodes']
	#names = len(season['episodes'])
	#cover = season['seasons'][1]['cover']
	#teste= episodio['episodes'][numero][0]['title']
	num_episodios = len(episodio['episodes'][numero])
	#xbmc.log("TESTE="+str(num_episodios),level=xbmc.LOGNOTICE)
	for i in range(num_episodios):
		#seasons = "Season "+str(numero)
		name = episodio['episodes'][numero][i]['title']
		id = episodio['episodes'][numero][i]['id']
		extensao = episodio['episodes'][numero][i]['container_extension']
		cover = episodio['info']['cover']
		iconimage = cover
		url = urlssS + str(id) + '.' + str(extensao)
		addItem(name,url,1,iconimage)
		
def LIST_VOD_S(url, name):
	servicos()
	reqs = urllib.request.Request(url, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	filme       = json.load(jsonSrc)
	if parental == "true" and name in a:
		text = plugintools.keyboard_input(default_text="", title="Parental lock")
		if text==plugintools.get_setting("parentalpin"):
			for i in range(len(filme)):
				filmes = filme[i]
				name = filmes["name"]
				id = filmes["stream_id"]
				extensao = filmes["container_extension"]
				iconimage = filmes["stream_icon"]
				url = urlssM + str(id) + '.' + str(extensao)
				addItem(name,url,1,iconimage)
		else:
			
			exit()
	else:
		for i in range(len(filme)):
			filmes = filme[i]
			name = filmes["name"]
			id = filmes["stream_id"]
			extensao = filmes["container_extension"]
			iconimage = filmes["stream_icon"]
			url = urlssM + str(id) + '.' + str(extensao)
			addItem(name,url,1,iconimage)
			
			
def LIST_LIVE_CAT(name):
	servicos()
	reqs = urllib.request.Request(url_live_cats, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	cat_live       = json.load(jsonSrc)	
	for i in range(len(cat_live)):
		cats_live = cat_live[i]
		name = cats_live["category_name"]
		id = cats_live["category_id"]
		if name == "PORTUGAL":
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Portugal.png')
		elif name in ['BRASIL','Brasil','brasil','BRAZIL','Brazil','brazil']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Brazil.png')
		elif name in ['ESPANHA','Espanha','espanha','SPAIN','Spain','spain']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Spain.png')
		elif name in ['FRANÇA','França','frança','FRANCA','Franca','franca','FRANCE','France','france']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'France.png')
		elif name in ['SUIÇA','Suiça','suiça','SUICA','Suica','suica']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Switzerland.png')
		elif name in ['ALEMANHA','Alemanha','alemanha','GERMANY','Germany','germany','DEUTSCHLAND','Deutschland','deutschland']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Germany.png')
		elif name in ['ITÁLIA','Itália','itália','ITALIA','Italia','italia','ITALY','Italy','italy']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Italy.png')
		elif name in ['HOLANDA','Holanda','holanda','HOLAND','Holand','holand','DENMARK','denmark','Denmark']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Denmark.png')
		elif name in ['BÉLGICA','Bélgica','bélgica','BELGIUM','Belgium','belgium','BELGICA','Belgica','belgica']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Belgium.png')
		elif name in ['USA','usa']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'USA.png')
		elif name in ['UK','uk','INGLATERRA','Inglaterra','inglaterra','ENGLAND','England','england']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'UK.png')
		elif name in ['CANAIS LOW','LOW','Low','low','Canais Low','canais low']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'low.png')
		elif name in ['RÁDIOS','Rádios','rádios','RADIOS','Radios','radios','RADIO','Radio','radio','RÁDIO','Rádio','rádio']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'radios.png')
		elif name in ['XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx','Xxx', 'FOR ADULTS','ADULTOS','Adultos','adultos']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), '18+.png')
		else:
			iconimage = icon
		url = url_live_c + str(id)
		addDir(name,url,7,iconimage)
		
def LIST_LIVE_CAT2(name):
	servicos()
	reqs = urllib.request.Request(url_live_cats, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	cat_live       = json.load(jsonSrc)	
	for i in range(len(cat_live)):
		cats_live = cat_live[i]
		name = cats_live["category_name"]
		id = cats_live["category_id"]
		if name == "PORTUGAL":
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Portugal.png')
		elif name in ['BRASIL','Brasil','brasil','BRAZIL','Brazil','brazil']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Brazil.png')
		elif name in ['ESPANHA','Espanha','espanha','SPAIN','Spain','spain']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Spain.png')
		elif name in ['FRANÇA','França','frança','FRANCA','Franca','franca','FRANCE','France','france']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'France.png')
		elif name in ['SUIÇA','Suiça','suiça','SUICA','Suica','suica']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Switzerland.png')
		elif name in ['ALEMANHA','Alemanha','alemanha','GERMANY','Germany','germany','DEUTSCHLAND','Deutschland','deutschland']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Germany.png')
		elif name in ['ITÁLIA','Itália','itália','ITALIA','Italia','italia','ITALY','Italy','italy']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Italy.png')
		elif name in ['HOLANDA','Holanda','holanda','HOLAND','Holand','holand','DENMARK','denmark','Denmark']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Denmark.png')
		elif name in ['BÉLGICA','Bélgica','bélgica','BELGIUM','Belgium','belgium','BELGICA','Belgica','belgica']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'Belgium.png')
		elif name in ['USA','usa']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'USA.png')
		elif name in ['UK','uk','INGLATERRA','Inglaterra','inglaterra','ENGLAND','England','england']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'UK.png')
		elif name in ['CANAIS LOW','LOW','Low','low','Canais Low','canais low']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'low.png')
		elif name in ['RÁDIOS','Rádios','rádios','RADIOS','Radios','radios','RADIO','Radio','radio','RÁDIO','Rádio','rádio']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), 'radios.png')
		elif name in ['XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx','Xxx', 'FOR ADULTS','ADULTOS','Adultos','adultos']:
			iconimage = os.path.join(os.path.join(bandeiras,'resources/art'), '18+.png')
		else:
			iconimage = icon
		url = url_live_c + str(id)
		addDir(name,url,13,iconimage)
		
def LIST_Live_S(url, name):
	servicos()
	reqs = urllib.request.Request(url, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	canal       = json.load(jsonSrc)
	if parental == "true" and name in a:
		text = plugintools.keyboard_input(default_text="", title="Parental lock")
		if text==plugintools.get_setting("parentalpin"):
			for i in range(len(canal)):
				canais = canal[i]
				name = canais["name"]
				id = canais["stream_id"]
				iconimage = canais["stream_icon"]
				url = urlss + str(id) + ts
				addItem(name,url,1,iconimage)
		else:
			exit()
	else:
		for i in range(len(canal)):
			canais = canal[i]
			name = canais["name"]
			id = canais["stream_id"]
			iconimage = canais["stream_icon"]
			url = urlss + str(id) + ts
			addItem(name,url,1,iconimage)
			
def LIST_Live_EPG(url, name, id):
	servicos()
	reqs = urllib.request.Request(url, headers={'User-Agent' : "Magic Browser"})
	jsonSrc     = urllib.request.urlopen(reqs)
	canal       = json.load(jsonSrc)
	if parental == "true" and name in a:
		text = plugintools.keyboard_input(default_text="", title="Parental lock")
		if text==plugintools.get_setting("parentalpin"):
			text_file = open(comparefile, "w")
			for i in range(len(canal)):
				canais = canal[i]
				name = canais["name"]
				id = canais["stream_id"]
				cha_id = canais["epg_channel_id"]
				if cha_id is not None:
					ident = url_epg + str(id) + '&limit=2'
					jsonSrcEpg = urllib.request.urlopen(ident)
					epg = json.load(jsonSrcEpg)
					try:
						epg_tit = epg["epg_listings"][0]["title"]
						epg_tit_next = epg["epg_listings"][1]["title"]
						start = epg["epg_listings"][0]["start_timestamp"]
						start_next = epg["epg_listings"][1]["start_timestamp"]
						start_f = datetime.datetime.fromtimestamp(int(start)).strftime('%H:%M')
						start_next_f = datetime.datetime.fromtimestamp(int(start_next)).strftime('%H:%M')
					except IndexError:
						epg_tit = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
						epg_tit_next = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
						start_f = ' '
						start_next_f = ' '
					epg_tit_final = base64.b64decode(epg_tit)
					epg_tit_final_next = base64.b64decode(epg_tit_next)
					iconimage = canais["stream_icon"]
					url = urlss + str(id) + ts
					name ='[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'  + ' [COLOR green]|> NOW: '+start_f+' < - >[/COLOR]' + epg_tit_final + ' \n[COLOR red]NEXT: '+start_next_f+' < - > [/COLOR]' + epg_tit_final_next + '[COLOR red] <|[/COLOR]'
					#addItem(name,url,150,iconimage)
				else:
					iconimage = canais["stream_icon"]
					url = urlss + str(id) + ts
					name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'
					#addItem(name,url,150,iconimage)
				text_file.write(name+'\n')
				
			
		else:
			exit()
	else:
		text_file = open(comparefile, "w")
		for i in range(len(canal)):
			canais = canal[i]
			name = canais["name"]
			id = canais["stream_id"]
			cha_id = canais["epg_channel_id"]
			if cha_id is not None:
				ident = url_epg + str(id) + '&limit=2'
				jsonSrcEpg = urllib.request.urlopen(ident)
				epg = json.load(jsonSrcEpg)
				try:
					epg_tit = epg["epg_listings"][0]["title"]
					epg_tit_next = epg["epg_listings"][1]["title"]
					start = epg["epg_listings"][0]["start_timestamp"]
					start_next = epg["epg_listings"][1]["start_timestamp"]
					start_f = datetime.datetime.fromtimestamp(int(start)).strftime('%H:%M')
					start_next_f = datetime.datetime.fromtimestamp(int(start_next)).strftime('%H:%M')
				except IndexError:
					epg_tit = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
					epg_tit_next = 'U2VtIEluZm9ybWFjYW8gZGUgUHJvZ3JhbWFjYW8='
					start_f = ' '
					start_next_f = ' '
				epg_tit_final = base64.b64decode(epg_tit)
				epg_tit_final_next = base64.b64decode(epg_tit_next)
				iconimage = canais["stream_icon"]
				url = urlss + str(id) + ts
				name ='[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'  + ' [COLOR green]|> NOW: '+start_f+' < - >[/COLOR]' + epg_tit_final + ' \n[COLOR red]NEXT: '+start_next_f+' < - > [/COLOR]' + epg_tit_final_next + '[COLOR red] <|[/COLOR]'
				
				#addItem(name,url,150,iconimage)
			else:
				iconimage = canais["stream_icon"]
				url = urlss + str(id) + ts
				name = '[B][COLOR dodgerblue]' + name + '[/COLOR][/B]'
				#addItem(name,url,150,iconimage)
			text_file.write(name+'\n')
	text_file.close()		
	r = open(comparefile)
	text = r.read()
	showText(text)	
	
def test(url,name):
		url = url+'|User-Agent=%s' % urllib.parse.quote('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36', safe='')
		playlist = xbmc.PlayList(1)
		playlist.clear()
		#listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
		
		label=name
		listitem = xbmcgui.ListItem(name)
		listitem.setArt({"fanart":  "DefaultVideo.png"})
		listitem.setArt({"thumb":  "DefaultVideo.png"})
		listitem.setArt({"landscape":  "DefaultVideo.png"})
		listitem.setArt({"poster": "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
		
		listitem.setInfo('video', {'Title': name})
		dialogWait = xbmcgui.DialogProgress()
		dialogWait.create('GRiptv', 'A carregar...'+ name)
		playlist.add(url, listitem)
		dialogWait.close()
		del dialogWait
		xbmcplugin.setResolvedUrl(int(sys.argv[1]),True,listitem)
		xbmcPlayer = xbmc.Player()
		xbmcPlayer.play(url,listitem)
		xbmc.log("TESTE="+icon,level=xbmc.LOGINFO)
		
def test2(url,name):
	
	try:
		source = abrir_url(url)
		
	except:
		xbmc.log('Unexpected error: {0:s} :{1:s}'.format(sys.exc_info()[0], sys.exc_info()[1]))
		source = ''
	if source:
		match = re.compile("[:=] '(.*)playlist\.m3u8\?([^']*)'\s*[,;]").findall(source)
		if match and match[0]:
			link = match[0][0] + tvi_resolver(match[0][0] + 'playlist.m3u8?' + match[0][1])
			abrir_url(link)
			playlist = xbmc.PlayList(1)
			playlist.clear()
			liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="DefaultVideo.png")
			liz.setInfo('Video', {})
			dialogWait = xbmcgui.DialogProgress()
			dialogWait.create('GRiptv', 'A carregar...'+ name)
			dialogWait.close()
			del dialogWait
			liz.setProperty('mimetype', 'video')
			playlist.add(link, liz)
			player = xbmc.Player()
			player.play(playlist)
	else:
		sys.exit(0)
		
def tvi_resolver(url):
	try:
		source = abrir_url(url)
	except:
		xbmc.log('Unexpected error: {0:s} :{1:s}'.format(sys.exc_info()[0], sys.exc_info()[1]))
		source = ''
	if source:
		try:
			tipostr = plugintools.get_setting('tipostr')
			tipostr_b = 'b(15|10)00000'
			if tipostr == '0':
				tipostr_b = 'b(15|10)00000'
			elif tipostr == '1':
				tipostr_b = 'b(75|50)0000'
			elif tipostr == '2':
				tipostr_b = 'b(25|20)0000'
			elif tipostr == '3':
				tipostr_b = 'b(64|48)000_ao'
			xbmc.log("tipostr="+tipostr +" tipostr_b="+tipostr_b)
			match = re.compile('(chunklist.*_' + tipostr_b + '\.m3u8\?[^\\n]*)').findall(source)
			if match and match[0]:
				return match[0][0]
			else:
				match = re.compile('(chunklist.*\.m3u8\?[^\\n]*)').findall(source)
				if match and match[0]:
					return match[0]
		except:
				xbmc.log('Unexpected error: {0:s} :{1:s}'.format(sys.exc_info()[0], sys.exc_info()[1]))
				return ''
	else:
		sys.exit(0)
		
def abrir_url(url ,referer = base_url):
    if not os.path.exists(datapath): xbmcvfs.mkdir(datapath)

    net = Net(cookie_file=cookie_TviFile, proxy='', user_agent=user_agent, http_debug=True)
    if os.path.exists(cookie_TviFile): net.set_cookies(cookie_TviFile)
    try:
        ref_data = {'Referer':referer}
        html = net.http_GET(url,headers=ref_data).content.encode('latin-1', 'ignore')
        net.save_cookies(cookie_TviFile)
        return html
    except:
        xbmc.log("abrir_url fail ="+url)
        return ''

		
def showText(text):
	id = 10147
	heading = '[COLOR snow][B]Programação[/COLOR][/B]'
	xbmc.executebuiltin('ActivateWindow(%d)' % id)
	xbmc.sleep(500)
	win = xbmcgui.Window(id)
	retry = 50
	while (retry > 0):
		try:
			xbmc.sleep(5)
			retry -= 1
			win.getControl(1).setLabel(heading)
			win.getControl(5).setText(text)
			#time.sleep(30)
			return
		except:
			pass
			

############################################################################################################################

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage,number_of_items):
	ok=True
	label=name
	liz = xbmcgui.ListItem(name)
	liz.setArt({"fanart": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"landscape": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"poster": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"thumb": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	#liz=xbmcgui.ListItem(name, iconImage="DefaultImage.png", thumbnailImage=iconimage)
	#liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
	#liz.setInfo( type='image', infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,totalItems=number_of_items)
	return ok

def addItem(name,url,mode,iconimage):
	name = name.encode('utf8', 'replace')
	u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
	ok=True
	label=name
	liz = xbmcgui.ListItem(name)
	liz.setArt({"fanart": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"landscape": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"poster": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"thumb": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	#liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	#liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
	liz.setInfo( type="Video", infoLabels={ "Title": name })
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
def addDir(name,url,mode,iconimage):
	global path
	name = name.encode('utf8', 'replace')
	u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
	ok=True
	label=name
	liz = xbmcgui.ListItem(label, path=path)
	#liz.setThumbnailImage(artwork or "special://home/addons/plugin.video.GRiptv/icon.png")
	liz.setArt({"fanart": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"poster": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"landscape": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	liz.setArt({"thumb": iconimage or "special://home/addons/plugin.video.GRiptv/fanart.jpg"})
	
	
	
	#liz=xbmcgui.ListItem.setart(name)
	#liz.setArt({'icon':"DefaultFolder.png", 'thumbnailImage':icon})
	liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
	liz.setInfo( type="Video", infoLabels={ "Title": name })
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

params=get_params()
url=None
name=None
mode=None

try: url=urllib.parse.unquote_plus(params["url"])
except: pass
try: name=urllib.parse.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass


if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: test(url,name)
elif mode==2: AllLIVE()
elif mode==3: TVI(url)
elif mode==4: LIST_LIVE_CAT(name)
elif mode==5: LIST_VOD_CAT()
elif mode==19: LIST_SER_CAT()
elif mode==6: LIST_VOD_S(url,name)
elif mode==20: LIST_SERIES(name,url)
elif mode==21: LIST_SEASONS(name,url)
elif mode==22: LIST_EPISODES(name,url)
elif mode==7: LIST_Live_S(url,name)
elif mode==8: U_Info()
elif mode==9: SETT()
elif mode==10: TVI_S(url)
elif mode==11: test2(url,name)
elif mode==12: TVI0()
elif mode==13: LIST_Live_EPG(url, name, id)
elif mode==14: LIST_LIVE_CAT2(name)
elif mode==15: SIC0()
elif mode==16: SIC_S(url)
elif mode==17: SICR()
elif mode==18: SIC_L(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
